let currentImageIndex = 0;
let images = [
    'images/image1.jpg',
    'images/image2.jpg',
    'images/image3.jpg',
    'images/image4.jpg',
    'images/image5.jpg',
    'images/image6.jpg',
    'images/image7.jpg',
    'images/image8.jpg'
];

// Function to display the current image in the gallery
function showImage(index) {
    const imageElement = document.getElementById('gallery-image');
    imageElement.src = images[index];
    highlightThumbnail(index);
}

// Function to highlight the selected thumbnail
function highlightThumbnail(index) {
    const thumbnails = document.querySelectorAll('.thumbnails img');
    thumbnails.forEach((thumbnail, i) => {
        thumbnail.style.border = i === index ? '2px solid #007bff' : '2px solid transparent';
    });
}

// Show thumbnails for all images
function showThumbnails() {
    const thumbnailsContainer = document.querySelector('.thumbnails');
    thumbnailsContainer.innerHTML = ''; // Clear existing thumbnails

    images.forEach((image, index) => {
        const thumbnail = document.createElement('img');
        thumbnail.src = image;
        thumbnail.alt = 'Image ${index + 1}';
        thumbnail.onclick = () => {
            currentImageIndex = index;
            showImage(currentImageIndex);
        };
        thumbnailsContainer.appendChild(thumbnail);
    });
}

// Navigate to the previous image
function prevImage() {
    currentImageIndex--;
    if (currentImageIndex < 0) {
        currentImageIndex = images.length - 1;
    }
    showImage(currentImageIndex);
}

// Navigate to the next image
function nextImage() {
    currentImageIndex++;
    if (currentImageIndex >= images.length) {
        currentImageIndex = 0;
    }
    showImage(currentImageIndex);
}

// Add a new image to the gallery
function addImage() {
    const imageUrl = document.getElementById('image-url').value;
    if (imageUrl) {
        images.push(imageUrl);
        showThumbnails(); // Refresh thumbnails
        document.getElementById('image-url').value = ''; // Clear input field
    } else {
        alert("Please enter a valid image URL.");
    }
}

// Delete the currently displayed image
function deleteImage() {
    if (images.length > 1) {
        images.splice(currentImageIndex, 1); // Remove current image
        currentImageIndex = currentImageIndex >= images.length ? 0 : currentImageIndex;
        showImage(currentImageIndex); // Show new current image
        showThumbnails(); // Refresh thumbnails
    } else {
        alert("Cannot delete the last image.");
    }
}

// Initial setup to load thumbnails and the first image
window.onload = function () {
    showThumbnails();
    showImage(currentImageIndex);
};